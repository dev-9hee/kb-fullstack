// src/eventBus.js
import mitt from "mitt";
const EventBus = mitt();
export default EventBus;
